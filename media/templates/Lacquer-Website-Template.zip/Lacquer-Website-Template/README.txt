Lacquer — website template
===========================

Made for: Salons, barbers and appointment businesses

WHAT TO DO FIRST
  1. Double-click index.html. That's your site, running in your browser.
  2. Read SETUP-GUIDE.pdf. It's three pages and covers everything below.

WHAT'S IN HERE
  index.html        every word on the page
  css/style.css     every colour, font and spacing value
  js/main.js        the interactive parts — you can leave this alone
  img/              every picture — replace these with your own
  SETUP-GUIDE.pdf   how to change the words, colours, pictures, and put it online

THE THREE THINGS PEOPLE CHANGE
  Words     open index.html, type over the text you see
  Colours   open css/style.css, edit the values in the :root block at the top
  Pictures  drop your photos into img/ and update the filenames in index.html

GOOD TO KNOW
  Nothing to install. No accounts, no subscriptions, no build step.
  Works in every modern browser, on phones and desktop.
  The contact form validates but doesn't send yet — the guide explains how to
  connect it free in about five minutes.

LICENCE
  Use this on one website, personal or commercial, for yourself or one client.
  Change anything you like. Please don't resell or redistribute the template
  itself, as-is or modified.

HELP
  Stuck on something? Message me through Etsy — help is included.
  If you'd rather I set the whole thing up for you with your words, pictures
  and domain, that's what the full build service is for.

  baraah-sites
